import React from "react";
import CourseGrid from "../components/CourseGrid";

const CoursesPage = () => {
  return (
    <>
        <CourseGrid />
    </>
  );
};

export default CoursesPage;
